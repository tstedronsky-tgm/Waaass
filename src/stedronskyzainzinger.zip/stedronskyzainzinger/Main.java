package stedronskyzainzinger;
import stedronskyzainzinger.chat.MyController;


/**
 * Klasse die den Chat und das Mail System ausfuehrt
 * @author Zainzinger Lukas
 * @author Stedronsky Thomas
 */
public class Main {
	public static void main(String[] args) {
		new MyController();
	}
} 