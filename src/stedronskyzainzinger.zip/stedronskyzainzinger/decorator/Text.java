package stedronskyzainzinger.decorator;

public class Text implements EditText{
	
	@Override
	public String edit(String text) {
		return text;
	}

}
