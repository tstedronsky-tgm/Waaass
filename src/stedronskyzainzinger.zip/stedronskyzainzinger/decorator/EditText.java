package stedronskyzainzinger.decorator;

public interface  EditText {
	public abstract String edit(String text);
}
