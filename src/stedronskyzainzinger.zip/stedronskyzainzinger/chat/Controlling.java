package stedronskyzainzinger.chat;


import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

import javax.jms.MessageListener;
/**
 * @author Zainzinger Lukas 
 * @author Stedronsky Thomas
 */
public interface Controlling extends ActionListener, MessageListener, KeyListener{

}
